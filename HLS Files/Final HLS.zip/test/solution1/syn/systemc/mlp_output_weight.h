// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __mlp_output_weight_H__
#define __mlp_output_weight_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct mlp_output_weight_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 32;
  static const unsigned AddressRange = 320;
  static const unsigned AddressWidth = 9;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in <sc_lv<AddressWidth> > address1;
sc_core::sc_in <sc_logic> ce1;
sc_core::sc_out <sc_lv<DataWidth> > q1;
sc_core::sc_in <sc_lv<AddressWidth> > address2;
sc_core::sc_in <sc_logic> ce2;
sc_core::sc_out <sc_lv<DataWidth> > q2;
sc_core::sc_in <sc_lv<AddressWidth> > address3;
sc_core::sc_in <sc_logic> ce3;
sc_core::sc_out <sc_lv<DataWidth> > q3;
sc_core::sc_in <sc_lv<AddressWidth> > address4;
sc_core::sc_in <sc_logic> ce4;
sc_core::sc_out <sc_lv<DataWidth> > q4;
sc_core::sc_in <sc_lv<AddressWidth> > address5;
sc_core::sc_in <sc_logic> ce5;
sc_core::sc_out <sc_lv<DataWidth> > q5;
sc_core::sc_in <sc_lv<AddressWidth> > address6;
sc_core::sc_in <sc_logic> ce6;
sc_core::sc_out <sc_lv<DataWidth> > q6;
sc_core::sc_in <sc_lv<AddressWidth> > address7;
sc_core::sc_in <sc_logic> ce7;
sc_core::sc_out <sc_lv<DataWidth> > q7;
sc_core::sc_in <sc_lv<AddressWidth> > address8;
sc_core::sc_in <sc_logic> ce8;
sc_core::sc_out <sc_lv<DataWidth> > q8;
sc_core::sc_in <sc_lv<AddressWidth> > address9;
sc_core::sc_in <sc_logic> ce9;
sc_core::sc_out <sc_lv<DataWidth> > q9;
sc_core::sc_in <sc_lv<AddressWidth> > address10;
sc_core::sc_in <sc_logic> ce10;
sc_core::sc_out <sc_lv<DataWidth> > q10;
sc_core::sc_in <sc_lv<AddressWidth> > address11;
sc_core::sc_in <sc_logic> ce11;
sc_core::sc_out <sc_lv<DataWidth> > q11;
sc_core::sc_in <sc_lv<AddressWidth> > address12;
sc_core::sc_in <sc_logic> ce12;
sc_core::sc_out <sc_lv<DataWidth> > q12;
sc_core::sc_in <sc_lv<AddressWidth> > address13;
sc_core::sc_in <sc_logic> ce13;
sc_core::sc_out <sc_lv<DataWidth> > q13;
sc_core::sc_in <sc_lv<AddressWidth> > address14;
sc_core::sc_in <sc_logic> ce14;
sc_core::sc_out <sc_lv<DataWidth> > q14;
sc_core::sc_in <sc_lv<AddressWidth> > address15;
sc_core::sc_in <sc_logic> ce15;
sc_core::sc_out <sc_lv<DataWidth> > q15;
sc_core::sc_in <sc_lv<AddressWidth> > address16;
sc_core::sc_in <sc_logic> ce16;
sc_core::sc_out <sc_lv<DataWidth> > q16;
sc_core::sc_in <sc_lv<AddressWidth> > address17;
sc_core::sc_in <sc_logic> ce17;
sc_core::sc_out <sc_lv<DataWidth> > q17;
sc_core::sc_in <sc_lv<AddressWidth> > address18;
sc_core::sc_in <sc_logic> ce18;
sc_core::sc_out <sc_lv<DataWidth> > q18;
sc_core::sc_in <sc_lv<AddressWidth> > address19;
sc_core::sc_in <sc_logic> ce19;
sc_core::sc_out <sc_lv<DataWidth> > q19;
sc_core::sc_in <sc_lv<AddressWidth> > address20;
sc_core::sc_in <sc_logic> ce20;
sc_core::sc_out <sc_lv<DataWidth> > q20;
sc_core::sc_in <sc_lv<AddressWidth> > address21;
sc_core::sc_in <sc_logic> ce21;
sc_core::sc_out <sc_lv<DataWidth> > q21;
sc_core::sc_in <sc_lv<AddressWidth> > address22;
sc_core::sc_in <sc_logic> ce22;
sc_core::sc_out <sc_lv<DataWidth> > q22;
sc_core::sc_in <sc_lv<AddressWidth> > address23;
sc_core::sc_in <sc_logic> ce23;
sc_core::sc_out <sc_lv<DataWidth> > q23;
sc_core::sc_in <sc_lv<AddressWidth> > address24;
sc_core::sc_in <sc_logic> ce24;
sc_core::sc_out <sc_lv<DataWidth> > q24;
sc_core::sc_in <sc_lv<AddressWidth> > address25;
sc_core::sc_in <sc_logic> ce25;
sc_core::sc_out <sc_lv<DataWidth> > q25;
sc_core::sc_in <sc_lv<AddressWidth> > address26;
sc_core::sc_in <sc_logic> ce26;
sc_core::sc_out <sc_lv<DataWidth> > q26;
sc_core::sc_in <sc_lv<AddressWidth> > address27;
sc_core::sc_in <sc_logic> ce27;
sc_core::sc_out <sc_lv<DataWidth> > q27;
sc_core::sc_in <sc_lv<AddressWidth> > address28;
sc_core::sc_in <sc_logic> ce28;
sc_core::sc_out <sc_lv<DataWidth> > q28;
sc_core::sc_in <sc_lv<AddressWidth> > address29;
sc_core::sc_in <sc_logic> ce29;
sc_core::sc_out <sc_lv<DataWidth> > q29;
sc_core::sc_in <sc_lv<AddressWidth> > address30;
sc_core::sc_in <sc_logic> ce30;
sc_core::sc_out <sc_lv<DataWidth> > q30;
sc_core::sc_in <sc_lv<AddressWidth> > address31;
sc_core::sc_in <sc_logic> ce31;
sc_core::sc_out <sc_lv<DataWidth> > q31;
sc_core::sc_in <sc_lv<AddressWidth> > address32;
sc_core::sc_in <sc_logic> ce32;
sc_core::sc_out <sc_lv<DataWidth> > q32;
sc_core::sc_in <sc_lv<AddressWidth> > address33;
sc_core::sc_in <sc_logic> ce33;
sc_core::sc_out <sc_lv<DataWidth> > q33;
sc_core::sc_in <sc_lv<AddressWidth> > address34;
sc_core::sc_in <sc_logic> ce34;
sc_core::sc_out <sc_lv<DataWidth> > q34;
sc_core::sc_in <sc_lv<AddressWidth> > address35;
sc_core::sc_in <sc_logic> ce35;
sc_core::sc_out <sc_lv<DataWidth> > q35;
sc_core::sc_in <sc_lv<AddressWidth> > address36;
sc_core::sc_in <sc_logic> ce36;
sc_core::sc_out <sc_lv<DataWidth> > q36;
sc_core::sc_in <sc_lv<AddressWidth> > address37;
sc_core::sc_in <sc_logic> ce37;
sc_core::sc_out <sc_lv<DataWidth> > q37;
sc_core::sc_in <sc_lv<AddressWidth> > address38;
sc_core::sc_in <sc_logic> ce38;
sc_core::sc_out <sc_lv<DataWidth> > q38;
sc_core::sc_in <sc_lv<AddressWidth> > address39;
sc_core::sc_in <sc_logic> ce39;
sc_core::sc_out <sc_lv<DataWidth> > q39;
sc_core::sc_in <sc_lv<AddressWidth> > address40;
sc_core::sc_in <sc_logic> ce40;
sc_core::sc_out <sc_lv<DataWidth> > q40;
sc_core::sc_in <sc_lv<AddressWidth> > address41;
sc_core::sc_in <sc_logic> ce41;
sc_core::sc_out <sc_lv<DataWidth> > q41;
sc_core::sc_in <sc_lv<AddressWidth> > address42;
sc_core::sc_in <sc_logic> ce42;
sc_core::sc_out <sc_lv<DataWidth> > q42;
sc_core::sc_in <sc_lv<AddressWidth> > address43;
sc_core::sc_in <sc_logic> ce43;
sc_core::sc_out <sc_lv<DataWidth> > q43;
sc_core::sc_in <sc_lv<AddressWidth> > address44;
sc_core::sc_in <sc_logic> ce44;
sc_core::sc_out <sc_lv<DataWidth> > q44;
sc_core::sc_in <sc_lv<AddressWidth> > address45;
sc_core::sc_in <sc_logic> ce45;
sc_core::sc_out <sc_lv<DataWidth> > q45;
sc_core::sc_in <sc_lv<AddressWidth> > address46;
sc_core::sc_in <sc_logic> ce46;
sc_core::sc_out <sc_lv<DataWidth> > q46;
sc_core::sc_in <sc_lv<AddressWidth> > address47;
sc_core::sc_in <sc_logic> ce47;
sc_core::sc_out <sc_lv<DataWidth> > q47;
sc_core::sc_in <sc_lv<AddressWidth> > address48;
sc_core::sc_in <sc_logic> ce48;
sc_core::sc_out <sc_lv<DataWidth> > q48;
sc_core::sc_in <sc_lv<AddressWidth> > address49;
sc_core::sc_in <sc_logic> ce49;
sc_core::sc_out <sc_lv<DataWidth> > q49;
sc_core::sc_in <sc_lv<AddressWidth> > address50;
sc_core::sc_in <sc_logic> ce50;
sc_core::sc_out <sc_lv<DataWidth> > q50;
sc_core::sc_in <sc_lv<AddressWidth> > address51;
sc_core::sc_in <sc_logic> ce51;
sc_core::sc_out <sc_lv<DataWidth> > q51;
sc_core::sc_in <sc_lv<AddressWidth> > address52;
sc_core::sc_in <sc_logic> ce52;
sc_core::sc_out <sc_lv<DataWidth> > q52;
sc_core::sc_in <sc_lv<AddressWidth> > address53;
sc_core::sc_in <sc_logic> ce53;
sc_core::sc_out <sc_lv<DataWidth> > q53;
sc_core::sc_in <sc_lv<AddressWidth> > address54;
sc_core::sc_in <sc_logic> ce54;
sc_core::sc_out <sc_lv<DataWidth> > q54;
sc_core::sc_in <sc_lv<AddressWidth> > address55;
sc_core::sc_in <sc_logic> ce55;
sc_core::sc_out <sc_lv<DataWidth> > q55;
sc_core::sc_in <sc_lv<AddressWidth> > address56;
sc_core::sc_in <sc_logic> ce56;
sc_core::sc_out <sc_lv<DataWidth> > q56;
sc_core::sc_in <sc_lv<AddressWidth> > address57;
sc_core::sc_in <sc_logic> ce57;
sc_core::sc_out <sc_lv<DataWidth> > q57;
sc_core::sc_in <sc_lv<AddressWidth> > address58;
sc_core::sc_in <sc_logic> ce58;
sc_core::sc_out <sc_lv<DataWidth> > q58;
sc_core::sc_in <sc_lv<AddressWidth> > address59;
sc_core::sc_in <sc_logic> ce59;
sc_core::sc_out <sc_lv<DataWidth> > q59;
sc_core::sc_in <sc_lv<AddressWidth> > address60;
sc_core::sc_in <sc_logic> ce60;
sc_core::sc_out <sc_lv<DataWidth> > q60;
sc_core::sc_in <sc_lv<AddressWidth> > address61;
sc_core::sc_in <sc_logic> ce61;
sc_core::sc_out <sc_lv<DataWidth> > q61;
sc_core::sc_in <sc_lv<AddressWidth> > address62;
sc_core::sc_in <sc_logic> ce62;
sc_core::sc_out <sc_lv<DataWidth> > q62;
sc_core::sc_in <sc_lv<AddressWidth> > address63;
sc_core::sc_in <sc_logic> ce63;
sc_core::sc_out <sc_lv<DataWidth> > q63;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(mlp_output_weight_ram) {
        ram[0] = "0b10111110000101101101000011111110";
        ram[1] = "0b00111110010011111100010111110111";
        ram[2] = "0b10111110010011110000001010110111";
        ram[3] = "0b10111101101110110110100010110101";
        ram[4] = "0b00111111010110101101010101100011";
        ram[5] = "0b10111110011100110011101111101101";
        ram[6] = "0b10111110010101111110111011110101";
        ram[7] = "0b10111011100100100011011110001110";
        ram[8] = "0b00111110001000100011111101100000";
        ram[9] = "0b10111101111111111010100011000011";
        ram[10] = "0b00111110110010110101000101010101";
        ram[11] = "0b00111100100111011000100000001100";
        ram[12] = "0b10111110000100011111001110100011";
        ram[13] = "0b00111111110100101001111101000111";
        ram[14] = "0b00111110001011010000101010110011";
        ram[15] = "0b00111101000100010000011001001000";
        ram[16] = "0b10111110001011111001010100110111";
        ram[17] = "0b00111101100100100001000010001100";
        ram[18] = "0b00111101110011111000100101000000";
        ram[19] = "0b10111110000111001011000010000101";
        ram[20] = "0b00111111010011011000010010101101";
        ram[21] = "0b10111111001100010111111011001010";
        ram[22] = "0b00111100111010000111011100101000";
        ram[23] = "0b10111111010001111100101010001010";
        ram[24] = "0b10111110010110101010000111010000";
        ram[25] = "0b10111110100100000100011100100010";
        ram[26] = "0b00111111010001111101001100000000";
        ram[27] = "0b00111110111011010011011100000011";
        ram[28] = "0b00111111000110010010101100000100";
        ram[29] = "0b10111101011111000000001101011000";
        ram[30] = "0b10111110010111101100111111001010";
        ram[31] = "0b00111100101000110100001100000110";
        ram[32] = "0b00111101001101001100111101001110";
        ram[33] = "0b00111110110001110101110110100111";
        ram[34] = "0b00111110000010001001111110100100";
        ram[35] = "0b10111110111010010111101000110010";
        ram[36] = "0b10111110001101101010010110100110";
        ram[37] = "0b00111110011011100111110001000111";
        ram[38] = "0b00111111000101011000011110110010";
        ram[39] = "0b00111101101011011101001010111001";
        ram[40] = "0b10111110001100000101110101110101";
        ram[41] = "0b00111110000001101010011101111110";
        ram[42] = "0b10111101010001010100111000011110";
        ram[43] = "0b10111111100010000000111110111111";
        ram[44] = "0b00111100100001011100010011010001";
        ram[45] = "0b00111101101101001011000001000011";
        ram[46] = "0b10111111001001101101111110110111";
        ram[47] = "0b10111111110100010001100011110101";
        ram[48] = "0b00111111010101100101010011001011";
        ram[49] = "0b00111101101101100010010110100100";
        ram[50] = "0b10111111001010111100100100101001";
        ram[51] = "0b00111110100011111101001000000110";
        ram[52] = "0b10111100001010011000110010100000";
        ram[53] = "0b00111100101110010111001111011100";
        ram[54] = "0b00111110011010001010101010101001";
        ram[55] = "0b00111111100011110000111001110010";
        ram[56] = "0b00111101011100111111011111111001";
        ram[57] = "0b10111110010101110101001011110101";
        ram[58] = "0b10111111101000100100011010001100";
        ram[59] = "0b10111101001110000100101111001000";
        ram[60] = "0b10111110010001000110011110111001";
        ram[61] = "0b10111110000100111110101101101000";
        ram[62] = "0b00111110100000110001111111011001";
        ram[63] = "0b00111101111110000001101011110001";
        ram[64] = "0b00111110010001010101011101100001";
        ram[65] = "0b00111101111110101101010100100010";
        ram[66] = "0b00111110010111000010110011010100";
        ram[67] = "0b10111110010101000001010110000010";
        ram[68] = "0b00111110001010011011111111100101";
        ram[69] = "0b10111110000110010111000111110101";
        ram[70] = "0b10111110101101111001101101000011";
        ram[71] = "0b10111010011010100111110011111111";
        ram[72] = "0b10111110010100111011111010001001";
        ram[73] = "0b00111110000111110101100000010001";
        ram[74] = "0b10111101100111100110010101100011";
        ram[75] = "0b00111101110110101011110111011001";
        ram[76] = "0b00111110001100001111111100000000";
        ram[77] = "0b10111110011101010100011001100011";
        ram[78] = "0b00111100111110100110011000100011";
        ram[79] = "0b10111110100100111110011110111100";
        ram[80] = "0b10111110011100001001000010011011";
        ram[81] = "0b00111110010000111010011110011110";
        ram[82] = "0b10111110011000010001100000010100";
        ram[83] = "0b10111110001100001110000101010000";
        ram[84] = "0b00111100110111001100110001011011";
        ram[85] = "0b00111110000000101010100000101011";
        ram[86] = "0b00111101000011111001100000101111";
        ram[87] = "0b10111101101111001001100100110111";
        ram[88] = "0b10111110001111110000000111100010";
        ram[89] = "0b10111101000010110111101010010010";
        ram[90] = "0b10111101000100010111111011101011";
        ram[91] = "0b00111110001010001010011111001011";
        ram[92] = "0b10111101001110110010011100100010";
        ram[93] = "0b10111101001100110000001010101100";
        ram[94] = "0b00111110011000010011110011111111";
        ram[95] = "0b10111101110011101011011101000101";
        ram[96] = "0b00111110010011010011111111111010";
        ram[97] = "0b10111110100011001110011000100101";
        ram[98] = "0b10111110010010000010001000110100";
        ram[99] = "0b10111101110101000111000000110100";
        ram[100] = "0b10111110011110111100011011101010";
        ram[101] = "0b10111110011110100111011001010101";
        ram[102] = "0b10111111000101001101011010010101";
        ram[103] = "0b10111110010001110000010101011111";
        ram[104] = "0b10111110011100010011100011100101";
        ram[105] = "0b00111110010110111001001010110011";
        ram[106] = "0b00111101111010000001100000010110";
        ram[107] = "0b00111101001000111010110110101001";
        ram[108] = "0b00111110010101010100111111100000";
        ram[109] = "0b00111101011110000100001110111110";
        ram[110] = "0b10111101011110101001101110001101";
        ram[111] = "0b10111101100110011101111101111100";
        ram[112] = "0b10111110001111010000110100001110";
        ram[113] = "0b10111100010001111010100001010110";
        ram[114] = "0b00111110010101101101101001011111";
        ram[115] = "0b00111011100010110111101001010110";
        ram[116] = "0b00111110001001001100010010111010";
        ram[117] = "0b00111111010010000101110001110100";
        ram[118] = "0b00111110001100001010011100111000";
        ram[119] = "0b10111110011111111110001001001100";
        ram[120] = "0b10111110001110000100111110010110";
        ram[121] = "0b00111100100011110000110100011111";
        ram[122] = "0b10111110010100101000001001000011";
        ram[123] = "0b00111101010101011101000110100011";
        ram[124] = "0b10111101011001111010100000000001";
        ram[125] = "0b10111101010100110010011011010001";
        ram[126] = "0b10111110101010001110011001100111";
        ram[127] = "0b00111110000000010011000010001010";
        ram[128] = "0b00111111101010101100100011010100";
        ram[129] = "0b10111111010110111001101110010011";
        ram[130] = "0b10111111000100001110000100001100";
        ram[131] = "0b10111111001000100001010000000010";
        ram[132] = "0b00111111100011011001010011001000";
        ram[133] = "0b00111101011010010101010110111101";
        ram[134] = "0b10111101100110110110100001011000";
        ram[135] = "0b10111110100111001011000111101010";
        ram[136] = "0b10111110101001011101011011001001";
        ram[137] = "0b00111101110011001110001101101110";
        ram[138] = "0b00111111100000000010000101000111";
        ram[139] = "0b00111111000100111011100101111000";
        ram[140] = "0b10111110111011100111110100100000";
        ram[141] = "0b10111110111100111111110001011001";
        ram[142] = "0b00111110000100000111011011111100";
        ram[143] = "0b10111111000000100111001101100011";
        ram[144] = "0b10111111011011110001110111001001";
        ram[145] = "0b11000000000001000001001110100111";
        ram[146] = "0b00111110100001000101100011011100";
        ram[147] = "0b00111111010111011011010001110100";
        ram[148] = "0b10111110110111011110101110000110";
        ram[149] = "0b10111111000101101011000000111110";
        ram[150] = "0b10111111101000110110010101111010";
        ram[151] = "0b00111110100111000110101000111111";
        ram[152] = "0b10111100011001111100010000110001";
        ram[153] = "0b00111111000110100110011000110011";
        ram[154] = "0b00111111010001011000011010110111";
        ram[155] = "0b10111111001100101010101010100111";
        ram[156] = "0b00111110011101101111001011000101";
        ram[157] = "0b10111110001010110001111110100010";
        ram[158] = "0b00111110000100001101011111110111";
        ram[159] = "0b00111110100000110000001101100001";
        ram[160] = "0b10111110010110010001100101011011";
        ram[161] = "0b10111111100111110011010010100111";
        ram[162] = "0b10111111000101110111001110001110";
        ram[163] = "0b00111111010110010110000010011110";
        ram[164] = "0b00111110100101110101101000101010";
        ram[165] = "0b00111110000011000100011010000110";
        ram[166] = "0b00111110111000111111011011100011";
        ram[167] = "0b00111101101111011101110110000101";
        ram[168] = "0b00111110100001010110101101001010";
        ram[169] = "0b10111111100101001111100011101010";
        ram[170] = "0b10111111010010011010001001011111";
        ram[171] = "0b00111101100100001100000000101010";
        ram[172] = "0b10111110100011000110001000011011";
        ram[173] = "0b00111110000110100100111001111010";
        ram[174] = "0b00111110100100000000001111010001";
        ram[175] = "0b11000000011001011110000000000111";
        ram[176] = "0b10111101111001100000001010011001";
        ram[177] = "0b10111100011011111110011100111011";
        ram[178] = "0b10111101100000111001110111011111";
        ram[179] = "0b00111110110001100000000101001001";
        ram[180] = "0b10111110110001111001110100001101";
        ram[181] = "0b10111110000010110111111010010101";
        ram[182] = "0b10111110101011001101100011111101";
        ram[183] = "0b00111101100101101011011110001100";
        ram[184] = "0b00111101101010010100011001010001";
        ram[185] = "0b11000000001010010000010011011101";
        ram[186] = "0b00111111000111011100010110011010";
        ram[187] = "0b10111100111011011110010100100010";
        ram[188] = "0b10111100011101100100100111110010";
        ram[189] = "0b00111110010010001010011111010100";
        ram[190] = "0b00111110100101000001001010111111";
        ram[191] = "0b10111101110000110011000100101001";
        ram[192] = "0b00111110000011001110101101000000";
        ram[193] = "0b10111101110001000100100100000000";
        ram[194] = "0b00111101101110101010101001010101";
        ram[195] = "0b00111110011000011100011111000110";
        ram[196] = "0b00111100100101111010010110111101";
        ram[197] = "0b10111100000100011001101101001111";
        ram[198] = "0b10111110010100010011011110010011";
        ram[199] = "0b10111110001111110011000110001000";
        ram[200] = "0b10111110100000000010001101111100";
        ram[201] = "0b00111101101110010000010110010111";
        ram[202] = "0b00111101001001100110110010100101";
        ram[203] = "0b10111110101011001010110000101100";
        ram[204] = "0b00111100110101000101111010010100";
        ram[205] = "0b10111110110111011111011000010110";
        ram[206] = "0b10111100010001100010101000010011";
        ram[207] = "0b00111101101010111111100111001111";
        ram[208] = "0b10111110010011010110111011000000";
        ram[209] = "0b00111110011010011101110101111100";
        ram[210] = "0b10111111101010111000010010110000";
        ram[211] = "0b00111110000001001101110111010010";
        ram[212] = "0b00111110001010101010111110001101";
        ram[213] = "0b10111101000111011101010000100011";
        ram[214] = "0b10111110011011101000011010010110";
        ram[215] = "0b00111110101000000010010000010111";
        ram[216] = "0b00111110111001100101001011101000";
        ram[217] = "0b00111110001000011000100011010010";
        ram[218] = "0b00111111100111010011110001111010";
        ram[219] = "0b10111110000011000101000010100101";
        ram[220] = "0b10111100011110111100001101000100";
        ram[221] = "0b10111101001011111000101001000110";
        ram[222] = "0b10111101010101110101101111000010";
        ram[223] = "0b00111110000010001010100000001010";
        ram[224] = "0b00111110011100010110110000100111";
        ram[225] = "0b00111101101110011110000011100101";
        ram[226] = "0b00111101100101001010011100110000";
        ram[227] = "0b00111110010111000011100000001010";
        ram[228] = "0b00111100001000110101010100101010";
        ram[229] = "0b00111101101101100110011100000001";
        ram[230] = "0b00111110100100000100010001110010";
        ram[231] = "0b00111110100001100000000001011000";
        ram[232] = "0b10111101100001101000100000011000";
        ram[233] = "0b10111111000100010001000100100001";
        ram[234] = "0b10111101100001010000101100100101";
        ram[235] = "0b00111110011110111000010011000000";
        ram[236] = "0b00111101110111100001101100110101";
        ram[237] = "0b10111110000100001101111100001111";
        ram[238] = "0b00111110001000101100000000110001";
        ram[239] = "0b00111101010010111110010011001010";
        ram[240] = "0b10111110100001010111011010100100";
        ram[241] = "0b10111110100101101010010110011110";
        ram[242] = "0b10111100000100111000101100000011";
        ram[243] = "0b10111110100001000011001001110101";
        ram[244] = "0b10111101111110111000010101111000";
        ram[245] = "0b10111110001110011011110011100101";
        ram[246] = "0b10111110101000010100100000001101";
        ram[247] = "0b10111101101010010111001001101000";
        ram[248] = "0b00111101101100001111010000110001";
        ram[249] = "0b00111110000110001100110100011010";
        ram[250] = "0b10111110011000001000101110011101";
        ram[251] = "0b00111101110110011010001011111100";
        ram[252] = "0b10111110100010001111010100000010";
        ram[253] = "0b00111100111010100110010100011110";
        ram[254] = "0b00111100100110010010111100011010";
        ram[255] = "0b00111101110110101010001001010111";
        ram[256] = "0b10111100101100110100101001101111";
        ram[257] = "0b00111110000001010000010110011000";
        ram[258] = "0b00111110101101111111110001101110";
        ram[259] = "0b00111110110111101110011010000010";
        ram[260] = "0b10111110000100000110101100001100";
        ram[261] = "0b00111100100110001011010010001101";
        ram[262] = "0b00111101110000110000110100000010";
        ram[263] = "0b00111110011010100011111101000101";
        ram[264] = "0b00111110101001111010010011110111";
        ram[265] = "0b00111110110110000001011000001011";
        ram[266] = "0b00111101010000101011111001101111";
        ram[267] = "0b00111110001110111100000001010100";
        ram[268] = "0b10111011101001111001000101001010";
        ram[269] = "0b00111110010101111101011100000111";
        ram[270] = "0b10111101000110011110101000010000";
        ram[271] = "0b00111110011000110111100011100101";
        ram[272] = "0b00111110010000101110111000001111";
        ram[273] = "0b00111110011000010101110010100010";
        ram[274] = "0b00111110100101101100111110100011";
        ram[275] = "0b00111101100011001010010101110001";
        ram[276] = "0b00111101110000100110011101011110";
        ram[277] = "0b00111110011110010101111000010010";
        ram[278] = "0b00111101000001100000100100100011";
        ram[279] = "0b10111110001100100111101010101000";
        ram[280] = "0b00111101100111101110000110110111";
        ram[281] = "0b00111110011001000111110000110111";
        ram[282] = "0b10111110100100010000100010000110";
        ram[283] = "0b10111101110000101101111101100101";
        ram[284] = "0b00111101011001001011010000101100";
        ram[285] = "0b10111110001110010011011001010011";
        ram[286] = "0b10111101000010010010101101001110";
        ram[287] = "0b00111110100100110101001111100110";
        ram[288] = "0b10111110001110000111110000010010";
        ram[289] = "0b00111110100111110101101100100111";
        ram[290] = "0b00111110001110101111010110000011";
        ram[291] = "0b10111101110111101001111111101111";
        ram[292] = "0b10111101110011001011110011111111";
        ram[293] = "0b00111110010110001010101111100000";
        ram[294] = "0b10111111101010000001111111111100";
        ram[295] = "0b10111100101111001001000110011101";
        ram[296] = "0b00111110100000011110001011100011";
        ram[297] = "0b00111101000001100100011001010001";
        ram[298] = "0b00111110101111001100100000011101";
        ram[299] = "0b10111101110001111000100001111011";
        ram[300] = "0b00111110110111000101000100100100";
        ram[301] = "0b00111011001001001011000100001011";
        ram[302] = "0b10111110001010111101111010110001";
        ram[303] = "0b00111101010111010001110110000011";
        ram[304] = "0b10111110000111110010010101101011";
        ram[305] = "0b00111101001100011011110011001001";
        ram[306] = "0b00111110100101001111000111100011";
        ram[307] = "0b00111110101101110010110110001100";
        ram[308] = "0b00111110101111000010110101011010";
        ram[309] = "0b00111101011010011000011111010100";
        ram[310] = "0b10111101111001101110000110100110";
        ram[311] = "0b10111100101100011100110001110000";
        ram[312] = "0b00111101101010001011111100011010";
        ram[313] = "0b10111101110111000111100100000111";
        ram[314] = "0b10111110011000001110101111001111";
        ram[315] = "0b10111101011101001111100110111110";
        ram[316] = "0b00111110101010011100000101011011";
        ram[317] = "0b10111110011000000110011000100110";
        ram[318] = "0b00111110010001101001010101111000";
        ram[319] = "0b00111101010110000010111110101010";


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();


SC_METHOD(prc_write_1);
  sensitive<<clk.pos();


SC_METHOD(prc_write_2);
  sensitive<<clk.pos();


SC_METHOD(prc_write_3);
  sensitive<<clk.pos();


SC_METHOD(prc_write_4);
  sensitive<<clk.pos();


SC_METHOD(prc_write_5);
  sensitive<<clk.pos();


SC_METHOD(prc_write_6);
  sensitive<<clk.pos();


SC_METHOD(prc_write_7);
  sensitive<<clk.pos();


SC_METHOD(prc_write_8);
  sensitive<<clk.pos();


SC_METHOD(prc_write_9);
  sensitive<<clk.pos();


SC_METHOD(prc_write_10);
  sensitive<<clk.pos();


SC_METHOD(prc_write_11);
  sensitive<<clk.pos();


SC_METHOD(prc_write_12);
  sensitive<<clk.pos();


SC_METHOD(prc_write_13);
  sensitive<<clk.pos();


SC_METHOD(prc_write_14);
  sensitive<<clk.pos();


SC_METHOD(prc_write_15);
  sensitive<<clk.pos();


SC_METHOD(prc_write_16);
  sensitive<<clk.pos();


SC_METHOD(prc_write_17);
  sensitive<<clk.pos();


SC_METHOD(prc_write_18);
  sensitive<<clk.pos();


SC_METHOD(prc_write_19);
  sensitive<<clk.pos();


SC_METHOD(prc_write_20);
  sensitive<<clk.pos();


SC_METHOD(prc_write_21);
  sensitive<<clk.pos();


SC_METHOD(prc_write_22);
  sensitive<<clk.pos();


SC_METHOD(prc_write_23);
  sensitive<<clk.pos();


SC_METHOD(prc_write_24);
  sensitive<<clk.pos();


SC_METHOD(prc_write_25);
  sensitive<<clk.pos();


SC_METHOD(prc_write_26);
  sensitive<<clk.pos();


SC_METHOD(prc_write_27);
  sensitive<<clk.pos();


SC_METHOD(prc_write_28);
  sensitive<<clk.pos();


SC_METHOD(prc_write_29);
  sensitive<<clk.pos();


SC_METHOD(prc_write_30);
  sensitive<<clk.pos();


SC_METHOD(prc_write_31);
  sensitive<<clk.pos();


SC_METHOD(prc_write_32);
  sensitive<<clk.pos();


SC_METHOD(prc_write_33);
  sensitive<<clk.pos();


SC_METHOD(prc_write_34);
  sensitive<<clk.pos();


SC_METHOD(prc_write_35);
  sensitive<<clk.pos();


SC_METHOD(prc_write_36);
  sensitive<<clk.pos();


SC_METHOD(prc_write_37);
  sensitive<<clk.pos();


SC_METHOD(prc_write_38);
  sensitive<<clk.pos();


SC_METHOD(prc_write_39);
  sensitive<<clk.pos();


SC_METHOD(prc_write_40);
  sensitive<<clk.pos();


SC_METHOD(prc_write_41);
  sensitive<<clk.pos();


SC_METHOD(prc_write_42);
  sensitive<<clk.pos();


SC_METHOD(prc_write_43);
  sensitive<<clk.pos();


SC_METHOD(prc_write_44);
  sensitive<<clk.pos();


SC_METHOD(prc_write_45);
  sensitive<<clk.pos();


SC_METHOD(prc_write_46);
  sensitive<<clk.pos();


SC_METHOD(prc_write_47);
  sensitive<<clk.pos();


SC_METHOD(prc_write_48);
  sensitive<<clk.pos();


SC_METHOD(prc_write_49);
  sensitive<<clk.pos();


SC_METHOD(prc_write_50);
  sensitive<<clk.pos();


SC_METHOD(prc_write_51);
  sensitive<<clk.pos();


SC_METHOD(prc_write_52);
  sensitive<<clk.pos();


SC_METHOD(prc_write_53);
  sensitive<<clk.pos();


SC_METHOD(prc_write_54);
  sensitive<<clk.pos();


SC_METHOD(prc_write_55);
  sensitive<<clk.pos();


SC_METHOD(prc_write_56);
  sensitive<<clk.pos();


SC_METHOD(prc_write_57);
  sensitive<<clk.pos();


SC_METHOD(prc_write_58);
  sensitive<<clk.pos();


SC_METHOD(prc_write_59);
  sensitive<<clk.pos();


SC_METHOD(prc_write_60);
  sensitive<<clk.pos();


SC_METHOD(prc_write_61);
  sensitive<<clk.pos();


SC_METHOD(prc_write_62);
  sensitive<<clk.pos();


SC_METHOD(prc_write_63);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


void prc_write_1()
{
    if (ce1.read() == sc_dt::Log_1) 
    {
            if(address1.read().is_01() && address1.read().to_uint()<AddressRange)
              q1 = ram[address1.read().to_uint()];
            else
              q1 = sc_lv<DataWidth>();
    }
}


void prc_write_2()
{
    if (ce2.read() == sc_dt::Log_1) 
    {
            if(address2.read().is_01() && address2.read().to_uint()<AddressRange)
              q2 = ram[address2.read().to_uint()];
            else
              q2 = sc_lv<DataWidth>();
    }
}


void prc_write_3()
{
    if (ce3.read() == sc_dt::Log_1) 
    {
            if(address3.read().is_01() && address3.read().to_uint()<AddressRange)
              q3 = ram[address3.read().to_uint()];
            else
              q3 = sc_lv<DataWidth>();
    }
}


void prc_write_4()
{
    if (ce4.read() == sc_dt::Log_1) 
    {
            if(address4.read().is_01() && address4.read().to_uint()<AddressRange)
              q4 = ram[address4.read().to_uint()];
            else
              q4 = sc_lv<DataWidth>();
    }
}


void prc_write_5()
{
    if (ce5.read() == sc_dt::Log_1) 
    {
            if(address5.read().is_01() && address5.read().to_uint()<AddressRange)
              q5 = ram[address5.read().to_uint()];
            else
              q5 = sc_lv<DataWidth>();
    }
}


void prc_write_6()
{
    if (ce6.read() == sc_dt::Log_1) 
    {
            if(address6.read().is_01() && address6.read().to_uint()<AddressRange)
              q6 = ram[address6.read().to_uint()];
            else
              q6 = sc_lv<DataWidth>();
    }
}


void prc_write_7()
{
    if (ce7.read() == sc_dt::Log_1) 
    {
            if(address7.read().is_01() && address7.read().to_uint()<AddressRange)
              q7 = ram[address7.read().to_uint()];
            else
              q7 = sc_lv<DataWidth>();
    }
}


void prc_write_8()
{
    if (ce8.read() == sc_dt::Log_1) 
    {
            if(address8.read().is_01() && address8.read().to_uint()<AddressRange)
              q8 = ram[address8.read().to_uint()];
            else
              q8 = sc_lv<DataWidth>();
    }
}


void prc_write_9()
{
    if (ce9.read() == sc_dt::Log_1) 
    {
            if(address9.read().is_01() && address9.read().to_uint()<AddressRange)
              q9 = ram[address9.read().to_uint()];
            else
              q9 = sc_lv<DataWidth>();
    }
}


void prc_write_10()
{
    if (ce10.read() == sc_dt::Log_1) 
    {
            if(address10.read().is_01() && address10.read().to_uint()<AddressRange)
              q10 = ram[address10.read().to_uint()];
            else
              q10 = sc_lv<DataWidth>();
    }
}


void prc_write_11()
{
    if (ce11.read() == sc_dt::Log_1) 
    {
            if(address11.read().is_01() && address11.read().to_uint()<AddressRange)
              q11 = ram[address11.read().to_uint()];
            else
              q11 = sc_lv<DataWidth>();
    }
}


void prc_write_12()
{
    if (ce12.read() == sc_dt::Log_1) 
    {
            if(address12.read().is_01() && address12.read().to_uint()<AddressRange)
              q12 = ram[address12.read().to_uint()];
            else
              q12 = sc_lv<DataWidth>();
    }
}


void prc_write_13()
{
    if (ce13.read() == sc_dt::Log_1) 
    {
            if(address13.read().is_01() && address13.read().to_uint()<AddressRange)
              q13 = ram[address13.read().to_uint()];
            else
              q13 = sc_lv<DataWidth>();
    }
}


void prc_write_14()
{
    if (ce14.read() == sc_dt::Log_1) 
    {
            if(address14.read().is_01() && address14.read().to_uint()<AddressRange)
              q14 = ram[address14.read().to_uint()];
            else
              q14 = sc_lv<DataWidth>();
    }
}


void prc_write_15()
{
    if (ce15.read() == sc_dt::Log_1) 
    {
            if(address15.read().is_01() && address15.read().to_uint()<AddressRange)
              q15 = ram[address15.read().to_uint()];
            else
              q15 = sc_lv<DataWidth>();
    }
}


void prc_write_16()
{
    if (ce16.read() == sc_dt::Log_1) 
    {
            if(address16.read().is_01() && address16.read().to_uint()<AddressRange)
              q16 = ram[address16.read().to_uint()];
            else
              q16 = sc_lv<DataWidth>();
    }
}


void prc_write_17()
{
    if (ce17.read() == sc_dt::Log_1) 
    {
            if(address17.read().is_01() && address17.read().to_uint()<AddressRange)
              q17 = ram[address17.read().to_uint()];
            else
              q17 = sc_lv<DataWidth>();
    }
}


void prc_write_18()
{
    if (ce18.read() == sc_dt::Log_1) 
    {
            if(address18.read().is_01() && address18.read().to_uint()<AddressRange)
              q18 = ram[address18.read().to_uint()];
            else
              q18 = sc_lv<DataWidth>();
    }
}


void prc_write_19()
{
    if (ce19.read() == sc_dt::Log_1) 
    {
            if(address19.read().is_01() && address19.read().to_uint()<AddressRange)
              q19 = ram[address19.read().to_uint()];
            else
              q19 = sc_lv<DataWidth>();
    }
}


void prc_write_20()
{
    if (ce20.read() == sc_dt::Log_1) 
    {
            if(address20.read().is_01() && address20.read().to_uint()<AddressRange)
              q20 = ram[address20.read().to_uint()];
            else
              q20 = sc_lv<DataWidth>();
    }
}


void prc_write_21()
{
    if (ce21.read() == sc_dt::Log_1) 
    {
            if(address21.read().is_01() && address21.read().to_uint()<AddressRange)
              q21 = ram[address21.read().to_uint()];
            else
              q21 = sc_lv<DataWidth>();
    }
}


void prc_write_22()
{
    if (ce22.read() == sc_dt::Log_1) 
    {
            if(address22.read().is_01() && address22.read().to_uint()<AddressRange)
              q22 = ram[address22.read().to_uint()];
            else
              q22 = sc_lv<DataWidth>();
    }
}


void prc_write_23()
{
    if (ce23.read() == sc_dt::Log_1) 
    {
            if(address23.read().is_01() && address23.read().to_uint()<AddressRange)
              q23 = ram[address23.read().to_uint()];
            else
              q23 = sc_lv<DataWidth>();
    }
}


void prc_write_24()
{
    if (ce24.read() == sc_dt::Log_1) 
    {
            if(address24.read().is_01() && address24.read().to_uint()<AddressRange)
              q24 = ram[address24.read().to_uint()];
            else
              q24 = sc_lv<DataWidth>();
    }
}


void prc_write_25()
{
    if (ce25.read() == sc_dt::Log_1) 
    {
            if(address25.read().is_01() && address25.read().to_uint()<AddressRange)
              q25 = ram[address25.read().to_uint()];
            else
              q25 = sc_lv<DataWidth>();
    }
}


void prc_write_26()
{
    if (ce26.read() == sc_dt::Log_1) 
    {
            if(address26.read().is_01() && address26.read().to_uint()<AddressRange)
              q26 = ram[address26.read().to_uint()];
            else
              q26 = sc_lv<DataWidth>();
    }
}


void prc_write_27()
{
    if (ce27.read() == sc_dt::Log_1) 
    {
            if(address27.read().is_01() && address27.read().to_uint()<AddressRange)
              q27 = ram[address27.read().to_uint()];
            else
              q27 = sc_lv<DataWidth>();
    }
}


void prc_write_28()
{
    if (ce28.read() == sc_dt::Log_1) 
    {
            if(address28.read().is_01() && address28.read().to_uint()<AddressRange)
              q28 = ram[address28.read().to_uint()];
            else
              q28 = sc_lv<DataWidth>();
    }
}


void prc_write_29()
{
    if (ce29.read() == sc_dt::Log_1) 
    {
            if(address29.read().is_01() && address29.read().to_uint()<AddressRange)
              q29 = ram[address29.read().to_uint()];
            else
              q29 = sc_lv<DataWidth>();
    }
}


void prc_write_30()
{
    if (ce30.read() == sc_dt::Log_1) 
    {
            if(address30.read().is_01() && address30.read().to_uint()<AddressRange)
              q30 = ram[address30.read().to_uint()];
            else
              q30 = sc_lv<DataWidth>();
    }
}


void prc_write_31()
{
    if (ce31.read() == sc_dt::Log_1) 
    {
            if(address31.read().is_01() && address31.read().to_uint()<AddressRange)
              q31 = ram[address31.read().to_uint()];
            else
              q31 = sc_lv<DataWidth>();
    }
}


void prc_write_32()
{
    if (ce32.read() == sc_dt::Log_1) 
    {
            if(address32.read().is_01() && address32.read().to_uint()<AddressRange)
              q32 = ram[address32.read().to_uint()];
            else
              q32 = sc_lv<DataWidth>();
    }
}


void prc_write_33()
{
    if (ce33.read() == sc_dt::Log_1) 
    {
            if(address33.read().is_01() && address33.read().to_uint()<AddressRange)
              q33 = ram[address33.read().to_uint()];
            else
              q33 = sc_lv<DataWidth>();
    }
}


void prc_write_34()
{
    if (ce34.read() == sc_dt::Log_1) 
    {
            if(address34.read().is_01() && address34.read().to_uint()<AddressRange)
              q34 = ram[address34.read().to_uint()];
            else
              q34 = sc_lv<DataWidth>();
    }
}


void prc_write_35()
{
    if (ce35.read() == sc_dt::Log_1) 
    {
            if(address35.read().is_01() && address35.read().to_uint()<AddressRange)
              q35 = ram[address35.read().to_uint()];
            else
              q35 = sc_lv<DataWidth>();
    }
}


void prc_write_36()
{
    if (ce36.read() == sc_dt::Log_1) 
    {
            if(address36.read().is_01() && address36.read().to_uint()<AddressRange)
              q36 = ram[address36.read().to_uint()];
            else
              q36 = sc_lv<DataWidth>();
    }
}


void prc_write_37()
{
    if (ce37.read() == sc_dt::Log_1) 
    {
            if(address37.read().is_01() && address37.read().to_uint()<AddressRange)
              q37 = ram[address37.read().to_uint()];
            else
              q37 = sc_lv<DataWidth>();
    }
}


void prc_write_38()
{
    if (ce38.read() == sc_dt::Log_1) 
    {
            if(address38.read().is_01() && address38.read().to_uint()<AddressRange)
              q38 = ram[address38.read().to_uint()];
            else
              q38 = sc_lv<DataWidth>();
    }
}


void prc_write_39()
{
    if (ce39.read() == sc_dt::Log_1) 
    {
            if(address39.read().is_01() && address39.read().to_uint()<AddressRange)
              q39 = ram[address39.read().to_uint()];
            else
              q39 = sc_lv<DataWidth>();
    }
}


void prc_write_40()
{
    if (ce40.read() == sc_dt::Log_1) 
    {
            if(address40.read().is_01() && address40.read().to_uint()<AddressRange)
              q40 = ram[address40.read().to_uint()];
            else
              q40 = sc_lv<DataWidth>();
    }
}


void prc_write_41()
{
    if (ce41.read() == sc_dt::Log_1) 
    {
            if(address41.read().is_01() && address41.read().to_uint()<AddressRange)
              q41 = ram[address41.read().to_uint()];
            else
              q41 = sc_lv<DataWidth>();
    }
}


void prc_write_42()
{
    if (ce42.read() == sc_dt::Log_1) 
    {
            if(address42.read().is_01() && address42.read().to_uint()<AddressRange)
              q42 = ram[address42.read().to_uint()];
            else
              q42 = sc_lv<DataWidth>();
    }
}


void prc_write_43()
{
    if (ce43.read() == sc_dt::Log_1) 
    {
            if(address43.read().is_01() && address43.read().to_uint()<AddressRange)
              q43 = ram[address43.read().to_uint()];
            else
              q43 = sc_lv<DataWidth>();
    }
}


void prc_write_44()
{
    if (ce44.read() == sc_dt::Log_1) 
    {
            if(address44.read().is_01() && address44.read().to_uint()<AddressRange)
              q44 = ram[address44.read().to_uint()];
            else
              q44 = sc_lv<DataWidth>();
    }
}


void prc_write_45()
{
    if (ce45.read() == sc_dt::Log_1) 
    {
            if(address45.read().is_01() && address45.read().to_uint()<AddressRange)
              q45 = ram[address45.read().to_uint()];
            else
              q45 = sc_lv<DataWidth>();
    }
}


void prc_write_46()
{
    if (ce46.read() == sc_dt::Log_1) 
    {
            if(address46.read().is_01() && address46.read().to_uint()<AddressRange)
              q46 = ram[address46.read().to_uint()];
            else
              q46 = sc_lv<DataWidth>();
    }
}


void prc_write_47()
{
    if (ce47.read() == sc_dt::Log_1) 
    {
            if(address47.read().is_01() && address47.read().to_uint()<AddressRange)
              q47 = ram[address47.read().to_uint()];
            else
              q47 = sc_lv<DataWidth>();
    }
}


void prc_write_48()
{
    if (ce48.read() == sc_dt::Log_1) 
    {
            if(address48.read().is_01() && address48.read().to_uint()<AddressRange)
              q48 = ram[address48.read().to_uint()];
            else
              q48 = sc_lv<DataWidth>();
    }
}


void prc_write_49()
{
    if (ce49.read() == sc_dt::Log_1) 
    {
            if(address49.read().is_01() && address49.read().to_uint()<AddressRange)
              q49 = ram[address49.read().to_uint()];
            else
              q49 = sc_lv<DataWidth>();
    }
}


void prc_write_50()
{
    if (ce50.read() == sc_dt::Log_1) 
    {
            if(address50.read().is_01() && address50.read().to_uint()<AddressRange)
              q50 = ram[address50.read().to_uint()];
            else
              q50 = sc_lv<DataWidth>();
    }
}


void prc_write_51()
{
    if (ce51.read() == sc_dt::Log_1) 
    {
            if(address51.read().is_01() && address51.read().to_uint()<AddressRange)
              q51 = ram[address51.read().to_uint()];
            else
              q51 = sc_lv<DataWidth>();
    }
}


void prc_write_52()
{
    if (ce52.read() == sc_dt::Log_1) 
    {
            if(address52.read().is_01() && address52.read().to_uint()<AddressRange)
              q52 = ram[address52.read().to_uint()];
            else
              q52 = sc_lv<DataWidth>();
    }
}


void prc_write_53()
{
    if (ce53.read() == sc_dt::Log_1) 
    {
            if(address53.read().is_01() && address53.read().to_uint()<AddressRange)
              q53 = ram[address53.read().to_uint()];
            else
              q53 = sc_lv<DataWidth>();
    }
}


void prc_write_54()
{
    if (ce54.read() == sc_dt::Log_1) 
    {
            if(address54.read().is_01() && address54.read().to_uint()<AddressRange)
              q54 = ram[address54.read().to_uint()];
            else
              q54 = sc_lv<DataWidth>();
    }
}


void prc_write_55()
{
    if (ce55.read() == sc_dt::Log_1) 
    {
            if(address55.read().is_01() && address55.read().to_uint()<AddressRange)
              q55 = ram[address55.read().to_uint()];
            else
              q55 = sc_lv<DataWidth>();
    }
}


void prc_write_56()
{
    if (ce56.read() == sc_dt::Log_1) 
    {
            if(address56.read().is_01() && address56.read().to_uint()<AddressRange)
              q56 = ram[address56.read().to_uint()];
            else
              q56 = sc_lv<DataWidth>();
    }
}


void prc_write_57()
{
    if (ce57.read() == sc_dt::Log_1) 
    {
            if(address57.read().is_01() && address57.read().to_uint()<AddressRange)
              q57 = ram[address57.read().to_uint()];
            else
              q57 = sc_lv<DataWidth>();
    }
}


void prc_write_58()
{
    if (ce58.read() == sc_dt::Log_1) 
    {
            if(address58.read().is_01() && address58.read().to_uint()<AddressRange)
              q58 = ram[address58.read().to_uint()];
            else
              q58 = sc_lv<DataWidth>();
    }
}


void prc_write_59()
{
    if (ce59.read() == sc_dt::Log_1) 
    {
            if(address59.read().is_01() && address59.read().to_uint()<AddressRange)
              q59 = ram[address59.read().to_uint()];
            else
              q59 = sc_lv<DataWidth>();
    }
}


void prc_write_60()
{
    if (ce60.read() == sc_dt::Log_1) 
    {
            if(address60.read().is_01() && address60.read().to_uint()<AddressRange)
              q60 = ram[address60.read().to_uint()];
            else
              q60 = sc_lv<DataWidth>();
    }
}


void prc_write_61()
{
    if (ce61.read() == sc_dt::Log_1) 
    {
            if(address61.read().is_01() && address61.read().to_uint()<AddressRange)
              q61 = ram[address61.read().to_uint()];
            else
              q61 = sc_lv<DataWidth>();
    }
}


void prc_write_62()
{
    if (ce62.read() == sc_dt::Log_1) 
    {
            if(address62.read().is_01() && address62.read().to_uint()<AddressRange)
              q62 = ram[address62.read().to_uint()];
            else
              q62 = sc_lv<DataWidth>();
    }
}


void prc_write_63()
{
    if (ce63.read() == sc_dt::Log_1) 
    {
            if(address63.read().is_01() && address63.read().to_uint()<AddressRange)
              q63 = ram[address63.read().to_uint()];
            else
              q63 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(mlp_output_weight) {


static const unsigned DataWidth = 32;
static const unsigned AddressRange = 320;
static const unsigned AddressWidth = 9;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in <sc_lv<AddressWidth> > address1;
sc_core::sc_in<sc_logic> ce1;
sc_core::sc_out <sc_lv<DataWidth> > q1;
sc_core::sc_in <sc_lv<AddressWidth> > address2;
sc_core::sc_in<sc_logic> ce2;
sc_core::sc_out <sc_lv<DataWidth> > q2;
sc_core::sc_in <sc_lv<AddressWidth> > address3;
sc_core::sc_in<sc_logic> ce3;
sc_core::sc_out <sc_lv<DataWidth> > q3;
sc_core::sc_in <sc_lv<AddressWidth> > address4;
sc_core::sc_in<sc_logic> ce4;
sc_core::sc_out <sc_lv<DataWidth> > q4;
sc_core::sc_in <sc_lv<AddressWidth> > address5;
sc_core::sc_in<sc_logic> ce5;
sc_core::sc_out <sc_lv<DataWidth> > q5;
sc_core::sc_in <sc_lv<AddressWidth> > address6;
sc_core::sc_in<sc_logic> ce6;
sc_core::sc_out <sc_lv<DataWidth> > q6;
sc_core::sc_in <sc_lv<AddressWidth> > address7;
sc_core::sc_in<sc_logic> ce7;
sc_core::sc_out <sc_lv<DataWidth> > q7;
sc_core::sc_in <sc_lv<AddressWidth> > address8;
sc_core::sc_in<sc_logic> ce8;
sc_core::sc_out <sc_lv<DataWidth> > q8;
sc_core::sc_in <sc_lv<AddressWidth> > address9;
sc_core::sc_in<sc_logic> ce9;
sc_core::sc_out <sc_lv<DataWidth> > q9;
sc_core::sc_in <sc_lv<AddressWidth> > address10;
sc_core::sc_in<sc_logic> ce10;
sc_core::sc_out <sc_lv<DataWidth> > q10;
sc_core::sc_in <sc_lv<AddressWidth> > address11;
sc_core::sc_in<sc_logic> ce11;
sc_core::sc_out <sc_lv<DataWidth> > q11;
sc_core::sc_in <sc_lv<AddressWidth> > address12;
sc_core::sc_in<sc_logic> ce12;
sc_core::sc_out <sc_lv<DataWidth> > q12;
sc_core::sc_in <sc_lv<AddressWidth> > address13;
sc_core::sc_in<sc_logic> ce13;
sc_core::sc_out <sc_lv<DataWidth> > q13;
sc_core::sc_in <sc_lv<AddressWidth> > address14;
sc_core::sc_in<sc_logic> ce14;
sc_core::sc_out <sc_lv<DataWidth> > q14;
sc_core::sc_in <sc_lv<AddressWidth> > address15;
sc_core::sc_in<sc_logic> ce15;
sc_core::sc_out <sc_lv<DataWidth> > q15;
sc_core::sc_in <sc_lv<AddressWidth> > address16;
sc_core::sc_in<sc_logic> ce16;
sc_core::sc_out <sc_lv<DataWidth> > q16;
sc_core::sc_in <sc_lv<AddressWidth> > address17;
sc_core::sc_in<sc_logic> ce17;
sc_core::sc_out <sc_lv<DataWidth> > q17;
sc_core::sc_in <sc_lv<AddressWidth> > address18;
sc_core::sc_in<sc_logic> ce18;
sc_core::sc_out <sc_lv<DataWidth> > q18;
sc_core::sc_in <sc_lv<AddressWidth> > address19;
sc_core::sc_in<sc_logic> ce19;
sc_core::sc_out <sc_lv<DataWidth> > q19;
sc_core::sc_in <sc_lv<AddressWidth> > address20;
sc_core::sc_in<sc_logic> ce20;
sc_core::sc_out <sc_lv<DataWidth> > q20;
sc_core::sc_in <sc_lv<AddressWidth> > address21;
sc_core::sc_in<sc_logic> ce21;
sc_core::sc_out <sc_lv<DataWidth> > q21;
sc_core::sc_in <sc_lv<AddressWidth> > address22;
sc_core::sc_in<sc_logic> ce22;
sc_core::sc_out <sc_lv<DataWidth> > q22;
sc_core::sc_in <sc_lv<AddressWidth> > address23;
sc_core::sc_in<sc_logic> ce23;
sc_core::sc_out <sc_lv<DataWidth> > q23;
sc_core::sc_in <sc_lv<AddressWidth> > address24;
sc_core::sc_in<sc_logic> ce24;
sc_core::sc_out <sc_lv<DataWidth> > q24;
sc_core::sc_in <sc_lv<AddressWidth> > address25;
sc_core::sc_in<sc_logic> ce25;
sc_core::sc_out <sc_lv<DataWidth> > q25;
sc_core::sc_in <sc_lv<AddressWidth> > address26;
sc_core::sc_in<sc_logic> ce26;
sc_core::sc_out <sc_lv<DataWidth> > q26;
sc_core::sc_in <sc_lv<AddressWidth> > address27;
sc_core::sc_in<sc_logic> ce27;
sc_core::sc_out <sc_lv<DataWidth> > q27;
sc_core::sc_in <sc_lv<AddressWidth> > address28;
sc_core::sc_in<sc_logic> ce28;
sc_core::sc_out <sc_lv<DataWidth> > q28;
sc_core::sc_in <sc_lv<AddressWidth> > address29;
sc_core::sc_in<sc_logic> ce29;
sc_core::sc_out <sc_lv<DataWidth> > q29;
sc_core::sc_in <sc_lv<AddressWidth> > address30;
sc_core::sc_in<sc_logic> ce30;
sc_core::sc_out <sc_lv<DataWidth> > q30;
sc_core::sc_in <sc_lv<AddressWidth> > address31;
sc_core::sc_in<sc_logic> ce31;
sc_core::sc_out <sc_lv<DataWidth> > q31;
sc_core::sc_in <sc_lv<AddressWidth> > address32;
sc_core::sc_in<sc_logic> ce32;
sc_core::sc_out <sc_lv<DataWidth> > q32;
sc_core::sc_in <sc_lv<AddressWidth> > address33;
sc_core::sc_in<sc_logic> ce33;
sc_core::sc_out <sc_lv<DataWidth> > q33;
sc_core::sc_in <sc_lv<AddressWidth> > address34;
sc_core::sc_in<sc_logic> ce34;
sc_core::sc_out <sc_lv<DataWidth> > q34;
sc_core::sc_in <sc_lv<AddressWidth> > address35;
sc_core::sc_in<sc_logic> ce35;
sc_core::sc_out <sc_lv<DataWidth> > q35;
sc_core::sc_in <sc_lv<AddressWidth> > address36;
sc_core::sc_in<sc_logic> ce36;
sc_core::sc_out <sc_lv<DataWidth> > q36;
sc_core::sc_in <sc_lv<AddressWidth> > address37;
sc_core::sc_in<sc_logic> ce37;
sc_core::sc_out <sc_lv<DataWidth> > q37;
sc_core::sc_in <sc_lv<AddressWidth> > address38;
sc_core::sc_in<sc_logic> ce38;
sc_core::sc_out <sc_lv<DataWidth> > q38;
sc_core::sc_in <sc_lv<AddressWidth> > address39;
sc_core::sc_in<sc_logic> ce39;
sc_core::sc_out <sc_lv<DataWidth> > q39;
sc_core::sc_in <sc_lv<AddressWidth> > address40;
sc_core::sc_in<sc_logic> ce40;
sc_core::sc_out <sc_lv<DataWidth> > q40;
sc_core::sc_in <sc_lv<AddressWidth> > address41;
sc_core::sc_in<sc_logic> ce41;
sc_core::sc_out <sc_lv<DataWidth> > q41;
sc_core::sc_in <sc_lv<AddressWidth> > address42;
sc_core::sc_in<sc_logic> ce42;
sc_core::sc_out <sc_lv<DataWidth> > q42;
sc_core::sc_in <sc_lv<AddressWidth> > address43;
sc_core::sc_in<sc_logic> ce43;
sc_core::sc_out <sc_lv<DataWidth> > q43;
sc_core::sc_in <sc_lv<AddressWidth> > address44;
sc_core::sc_in<sc_logic> ce44;
sc_core::sc_out <sc_lv<DataWidth> > q44;
sc_core::sc_in <sc_lv<AddressWidth> > address45;
sc_core::sc_in<sc_logic> ce45;
sc_core::sc_out <sc_lv<DataWidth> > q45;
sc_core::sc_in <sc_lv<AddressWidth> > address46;
sc_core::sc_in<sc_logic> ce46;
sc_core::sc_out <sc_lv<DataWidth> > q46;
sc_core::sc_in <sc_lv<AddressWidth> > address47;
sc_core::sc_in<sc_logic> ce47;
sc_core::sc_out <sc_lv<DataWidth> > q47;
sc_core::sc_in <sc_lv<AddressWidth> > address48;
sc_core::sc_in<sc_logic> ce48;
sc_core::sc_out <sc_lv<DataWidth> > q48;
sc_core::sc_in <sc_lv<AddressWidth> > address49;
sc_core::sc_in<sc_logic> ce49;
sc_core::sc_out <sc_lv<DataWidth> > q49;
sc_core::sc_in <sc_lv<AddressWidth> > address50;
sc_core::sc_in<sc_logic> ce50;
sc_core::sc_out <sc_lv<DataWidth> > q50;
sc_core::sc_in <sc_lv<AddressWidth> > address51;
sc_core::sc_in<sc_logic> ce51;
sc_core::sc_out <sc_lv<DataWidth> > q51;
sc_core::sc_in <sc_lv<AddressWidth> > address52;
sc_core::sc_in<sc_logic> ce52;
sc_core::sc_out <sc_lv<DataWidth> > q52;
sc_core::sc_in <sc_lv<AddressWidth> > address53;
sc_core::sc_in<sc_logic> ce53;
sc_core::sc_out <sc_lv<DataWidth> > q53;
sc_core::sc_in <sc_lv<AddressWidth> > address54;
sc_core::sc_in<sc_logic> ce54;
sc_core::sc_out <sc_lv<DataWidth> > q54;
sc_core::sc_in <sc_lv<AddressWidth> > address55;
sc_core::sc_in<sc_logic> ce55;
sc_core::sc_out <sc_lv<DataWidth> > q55;
sc_core::sc_in <sc_lv<AddressWidth> > address56;
sc_core::sc_in<sc_logic> ce56;
sc_core::sc_out <sc_lv<DataWidth> > q56;
sc_core::sc_in <sc_lv<AddressWidth> > address57;
sc_core::sc_in<sc_logic> ce57;
sc_core::sc_out <sc_lv<DataWidth> > q57;
sc_core::sc_in <sc_lv<AddressWidth> > address58;
sc_core::sc_in<sc_logic> ce58;
sc_core::sc_out <sc_lv<DataWidth> > q58;
sc_core::sc_in <sc_lv<AddressWidth> > address59;
sc_core::sc_in<sc_logic> ce59;
sc_core::sc_out <sc_lv<DataWidth> > q59;
sc_core::sc_in <sc_lv<AddressWidth> > address60;
sc_core::sc_in<sc_logic> ce60;
sc_core::sc_out <sc_lv<DataWidth> > q60;
sc_core::sc_in <sc_lv<AddressWidth> > address61;
sc_core::sc_in<sc_logic> ce61;
sc_core::sc_out <sc_lv<DataWidth> > q61;
sc_core::sc_in <sc_lv<AddressWidth> > address62;
sc_core::sc_in<sc_logic> ce62;
sc_core::sc_out <sc_lv<DataWidth> > q62;
sc_core::sc_in <sc_lv<AddressWidth> > address63;
sc_core::sc_in<sc_logic> ce63;
sc_core::sc_out <sc_lv<DataWidth> > q63;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


mlp_output_weight_ram* meminst;


SC_CTOR(mlp_output_weight) {
meminst = new mlp_output_weight_ram("mlp_output_weight_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->address1(address1);
meminst->ce1(ce1);
meminst->q1(q1);

meminst->address2(address2);
meminst->ce2(ce2);
meminst->q2(q2);

meminst->address3(address3);
meminst->ce3(ce3);
meminst->q3(q3);

meminst->address4(address4);
meminst->ce4(ce4);
meminst->q4(q4);

meminst->address5(address5);
meminst->ce5(ce5);
meminst->q5(q5);

meminst->address6(address6);
meminst->ce6(ce6);
meminst->q6(q6);

meminst->address7(address7);
meminst->ce7(ce7);
meminst->q7(q7);

meminst->address8(address8);
meminst->ce8(ce8);
meminst->q8(q8);

meminst->address9(address9);
meminst->ce9(ce9);
meminst->q9(q9);

meminst->address10(address10);
meminst->ce10(ce10);
meminst->q10(q10);

meminst->address11(address11);
meminst->ce11(ce11);
meminst->q11(q11);

meminst->address12(address12);
meminst->ce12(ce12);
meminst->q12(q12);

meminst->address13(address13);
meminst->ce13(ce13);
meminst->q13(q13);

meminst->address14(address14);
meminst->ce14(ce14);
meminst->q14(q14);

meminst->address15(address15);
meminst->ce15(ce15);
meminst->q15(q15);

meminst->address16(address16);
meminst->ce16(ce16);
meminst->q16(q16);

meminst->address17(address17);
meminst->ce17(ce17);
meminst->q17(q17);

meminst->address18(address18);
meminst->ce18(ce18);
meminst->q18(q18);

meminst->address19(address19);
meminst->ce19(ce19);
meminst->q19(q19);

meminst->address20(address20);
meminst->ce20(ce20);
meminst->q20(q20);

meminst->address21(address21);
meminst->ce21(ce21);
meminst->q21(q21);

meminst->address22(address22);
meminst->ce22(ce22);
meminst->q22(q22);

meminst->address23(address23);
meminst->ce23(ce23);
meminst->q23(q23);

meminst->address24(address24);
meminst->ce24(ce24);
meminst->q24(q24);

meminst->address25(address25);
meminst->ce25(ce25);
meminst->q25(q25);

meminst->address26(address26);
meminst->ce26(ce26);
meminst->q26(q26);

meminst->address27(address27);
meminst->ce27(ce27);
meminst->q27(q27);

meminst->address28(address28);
meminst->ce28(ce28);
meminst->q28(q28);

meminst->address29(address29);
meminst->ce29(ce29);
meminst->q29(q29);

meminst->address30(address30);
meminst->ce30(ce30);
meminst->q30(q30);

meminst->address31(address31);
meminst->ce31(ce31);
meminst->q31(q31);

meminst->address32(address32);
meminst->ce32(ce32);
meminst->q32(q32);

meminst->address33(address33);
meminst->ce33(ce33);
meminst->q33(q33);

meminst->address34(address34);
meminst->ce34(ce34);
meminst->q34(q34);

meminst->address35(address35);
meminst->ce35(ce35);
meminst->q35(q35);

meminst->address36(address36);
meminst->ce36(ce36);
meminst->q36(q36);

meminst->address37(address37);
meminst->ce37(ce37);
meminst->q37(q37);

meminst->address38(address38);
meminst->ce38(ce38);
meminst->q38(q38);

meminst->address39(address39);
meminst->ce39(ce39);
meminst->q39(q39);

meminst->address40(address40);
meminst->ce40(ce40);
meminst->q40(q40);

meminst->address41(address41);
meminst->ce41(ce41);
meminst->q41(q41);

meminst->address42(address42);
meminst->ce42(ce42);
meminst->q42(q42);

meminst->address43(address43);
meminst->ce43(ce43);
meminst->q43(q43);

meminst->address44(address44);
meminst->ce44(ce44);
meminst->q44(q44);

meminst->address45(address45);
meminst->ce45(ce45);
meminst->q45(q45);

meminst->address46(address46);
meminst->ce46(ce46);
meminst->q46(q46);

meminst->address47(address47);
meminst->ce47(ce47);
meminst->q47(q47);

meminst->address48(address48);
meminst->ce48(ce48);
meminst->q48(q48);

meminst->address49(address49);
meminst->ce49(ce49);
meminst->q49(q49);

meminst->address50(address50);
meminst->ce50(ce50);
meminst->q50(q50);

meminst->address51(address51);
meminst->ce51(ce51);
meminst->q51(q51);

meminst->address52(address52);
meminst->ce52(ce52);
meminst->q52(q52);

meminst->address53(address53);
meminst->ce53(ce53);
meminst->q53(q53);

meminst->address54(address54);
meminst->ce54(ce54);
meminst->q54(q54);

meminst->address55(address55);
meminst->ce55(ce55);
meminst->q55(q55);

meminst->address56(address56);
meminst->ce56(ce56);
meminst->q56(q56);

meminst->address57(address57);
meminst->ce57(ce57);
meminst->q57(q57);

meminst->address58(address58);
meminst->ce58(ce58);
meminst->q58(q58);

meminst->address59(address59);
meminst->ce59(ce59);
meminst->q59(q59);

meminst->address60(address60);
meminst->ce60(ce60);
meminst->q60(q60);

meminst->address61(address61);
meminst->ce61(ce61);
meminst->q61(q61);

meminst->address62(address62);
meminst->ce62(ce62);
meminst->q62(q62);

meminst->address63(address63);
meminst->ce63(ce63);
meminst->q63(q63);

meminst->reset(reset);
meminst->clk(clk);
}
~mlp_output_weight() {
    delete meminst;
}


};//endmodule
#endif
